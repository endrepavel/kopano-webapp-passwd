## 1.0 (17th Dec 2013)

  - Password change functionality when using DB or LDAP plugin

## 1.1 (19th Dec 2013)

  - Bug fixes for LDAP plugin

## 1.2 (20th May 2015)

  - Bug fixes for LDAP plugin
  - Improved UI
  
## 1.3 (14th February 2017)

	- Adapted to Kopano WebApp 3.3.0 for DB only, not tested/fixed for LDAP
	- project renamed from zarafa-webapp-passwd to kopano-webapp-passwd